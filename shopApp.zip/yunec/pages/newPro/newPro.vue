<template>
	<view class="container">
		<view class="themeArea">
			<view class="themeItem">
				<view class="themeItem_pic">
					<image src="https://i1.ygimg.cn/pics/mobile/homepage/2019/05/1558418890257.jpg" mode=""></image>
				</view>
				<view class="themeItem_scroll">
					<scroll-view scroll-x="true">
						<view class="scrollView_con">
							<view class="newproItem" @tap="navToDetailPage">
								<image src="//i2.ygimg.cn/pics/adidasclassic/2019/101212062/101212062_01_mb.jpg?4"
								 mode=""></image>
								<view class="newproItem_con">
									<view class="newproItem_price">
										<view><text>￥</text><text>564</text></view>
									</view>
								</view>
							</view>
							<view class="newproItem" @tap="navToDetailPage">
								<image src="//i2.ygimg.cn/pics/adidasclassic/2019/101212062/101212062_01_mb.jpg?4"
								 mode=""></image>
								<view class="newproItem_con">
									<view class="newproItem_price">
										<view><text>￥</text><text>564</text></view>
									</view>
								</view>
							</view>
							<view class="newproItem" @tap="navToDetailPage">
								<image src="//i2.ygimg.cn/pics/adidasclassic/2019/101212062/101212062_01_mb.jpg?4"
								 mode=""></image>
								<view class="newproItem_con">
									<view class="newproItem_price">
										<view><text>￥</text><text>564</text></view>
									</view>
								</view>
							</view>
							<view class="newproItem" @tap="navToDetailPage">
								<image src="//i2.ygimg.cn/pics/adidasclassic/2019/101212062/101212062_01_mb.jpg?4"
								 mode=""></image>
								<view class="newproItem_con">
									<view class="newproItem_price">
										<view><text>￥</text><text>564</text></view>
									</view>
								</view>
							</view>
							<view class="newproItem" @tap="navToDetailPage">
								<image src="//i2.ygimg.cn/pics/adidasclassic/2019/101212062/101212062_01_mb.jpg?4"
								 mode=""></image>
								<view class="newproItem_con">
									<view class="newproItem_price">
										<view><text>￥</text><text>564</text></view>
									</view>
								</view>
							</view>
							<view class="newproItem" @tap="navToDetailPage">
								<image src="//i2.ygimg.cn/pics/adidasclassic/2019/101212062/101212062_01_mb.jpg?4"
								 mode=""></image>
								<view class="newproItem_con">
									<view class="newproItem_price">
										<view><text>￥</text><text>564</text></view>
									</view>
								</view>
							</view>
							<view class="newproItem" @tap="navToDetailPage">
								<image src="//i2.ygimg.cn/pics/adidasclassic/2019/101212062/101212062_01_mb.jpg?4"
								 mode=""></image>
								<view class="newproItem_con">
									<view class="newproItem_price">
										<view><text>￥</text><text>564</text></view>
									</view>
								</view>
							</view>
						</view>
					</scroll-view>
				</view>
			</view>
			<view class="themeItem">
				<view class="themeItem_pic">
					<image src="https://i1.ygimg.cn/pics/mobile/homepage/2019/05/1558418890257.jpg" mode=""></image>
				</view>
				<view class="themeItem_scroll">
					<scroll-view scroll-x="true">
						<view class="scrollView_con">
							<view class="newproItem" @tap="navToDetailPage">
								<image src="//i2.ygimg.cn/pics/adidasclassic/2019/101212062/101212062_01_mb.jpg?4"
								 mode=""></image>
								<view class="newproItem_con">
									<view class="newproItem_price">
										<view><text>￥</text><text>564</text></view>
									</view>
								</view>
							</view>
							<view class="newproItem" @tap="navToDetailPage">
								<image src="//i2.ygimg.cn/pics/adidasclassic/2019/101212062/101212062_01_mb.jpg?4"
								 mode=""></image>
								<view class="newproItem_con">
									<view class="newproItem_price">
										<view><text>￥</text><text>564</text></view>
									</view>
								</view>
							</view>
							<view class="newproItem" @tap="navToDetailPage">
								<image src="//i2.ygimg.cn/pics/adidasclassic/2019/101212062/101212062_01_mb.jpg?4"
								 mode=""></image>
								<view class="newproItem_con">
									<view class="newproItem_price">
										<view><text>￥</text><text>564</text></view>
									</view>
								</view>
							</view>
							<view class="newproItem" @tap="navToDetailPage">
								<image src="//i2.ygimg.cn/pics/adidasclassic/2019/101212062/101212062_01_mb.jpg?4"
								 mode=""></image>
								<view class="newproItem_con">
									<view class="newproItem_price">
										<view><text>￥</text><text>564</text></view>
									</view>
								</view>
							</view>
						</view>
					</scroll-view>
				</view>
			</view>
			<view class="themeItem">
				<view class="themeItem_pic">
					<image src="https://i1.ygimg.cn/pics/mobile/homepage/2019/05/1558418890257.jpg" mode=""></image>
				</view>
				<view class="themeItem_scroll">
					<scroll-view scroll-x="true">
						<view class="scrollView_con">
							<view class="newproItem" @tap="navToDetailPage">
								<image src="//i2.ygimg.cn/pics/adidasclassic/2019/101212062/101212062_01_mb.jpg?4"
								 mode=""></image>
								<view class="newproItem_con">
									<view class="newproItem_price">
										<view><text>￥</text><text>564</text></view>
									</view>
								</view>
							</view>
							<view class="newproItem" @tap="navToDetailPage">
								<image src="//i2.ygimg.cn/pics/adidasclassic/2019/101212062/101212062_01_mb.jpg?4"
								 mode=""></image>
								<view class="newproItem_con">
									<view class="newproItem_price">
										<view><text>￥</text><text>564</text></view>
									</view>
								</view>
							</view>
							<view class="newproItem" @tap="navToDetailPage">
								<image src="//i2.ygimg.cn/pics/adidasclassic/2019/101212062/101212062_01_mb.jpg?4"
								 mode=""></image>
								<view class="newproItem_con">
									<view class="newproItem_price">
										<view><text>￥</text><text>564</text></view>
									</view>
								</view>
							</view>
							<view class="newproItem" @tap="navToDetailPage">
								<image src="//i2.ygimg.cn/pics/adidasclassic/2019/101212062/101212062_01_mb.jpg?4"
								 mode=""></image>
								<view class="newproItem_con">
									<view class="newproItem_price">
										<view><text>￥</text><text>564</text></view>
									</view>
								</view>
							</view>
						</view>
					</scroll-view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
</script>

<style lang="scss">
	.themeArea{
		width: 100%;
		margin-top: 15upx;
	}
	.themeItem{
		background-color: #ffffff;
		padding:15upx; 
		margin-bottom: 15upx;
		.themeItem_pic{
			image{
				width: 100%;
				height: 250upx;
			}
		}
	}
	.themeItem_scroll{
		padding: 20upx;
	}
	.scrollView_con{
		 display: flex;
		  white-space: nowrap;
	}
	
	.newproItem_price{
		font-size: 32upx;
		color: red;
	}
	.newproItem{
		width: 200upx;
		margin-right: 30upx;
	}
	.newproItem image{
		width: 200upx;
		height: 200upx;
	}
</style>
